"""
teleop_node.py — Manual bot control via keyboard.

Controls:
  ↑ or W  = Move forward one grid cell
  ← or A  = Rotate left 90 degrees
  → or D  = Rotate right 90 degrees
  ↓ or S  = Rotate 180 degrees (turn around)
  1-9     = Select bot_01 through bot_09
  Q       = Quit

Usage:
  ros2 run swarm_controller teleop
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import sys
import os
import termios
import tty
import select
import time


class TeleopNode(Node):
    def __init__(self):
        super().__init__('teleop')

        self.declare_parameter('grid_size_mm', 150)
        self.declare_parameter('bot_ids', ['bot_01', 'bot_02'])

        self.grid_size = self.get_parameter('grid_size_mm').value
        self.bot_ids = self.get_parameter('bot_ids').value

        self.selected_bot = self.bot_ids[0] if self.bot_ids else 'bot_01'
        self.seq = 0
        self.heading = 0.0
        self.waiting = False
        self.last_cmd_time = 0

        # Publishers
        self.cmd_pubs = {}
        for bid in self.bot_ids:
            self.cmd_pubs[bid] = self.create_publisher(String, f'/{bid}/cmd', 10)

        # Status subscribers
        for bid in self.bot_ids:
            self.create_subscription(
                String, f'/{bid}/status',
                lambda msg, b=bid: self.on_status(b, msg), 10)

        self.get_logger().info(f'Teleop ready. Selected: {self.selected_bot}')

    def on_status(self, bot_id, msg: String):
        parts = msg.data.split(':')
        if len(parts) >= 3 and parts[1] == 'DONE':
            if bot_id == self.selected_bot and self.waiting:
                self.waiting = False

    def send_cmd(self, cmd_str):
        # Debounce — ignore if sent less than 200ms ago
        now = time.time()
        if now - self.last_cmd_time < 0.2:
            return
        self.last_cmd_time = now

        self.seq += 1
        full_cmd = f'{cmd_str}:{self.seq}'
        msg = String()
        msg.data = full_cmd
        if self.selected_bot in self.cmd_pubs:
            self.cmd_pubs[self.selected_bot].publish(msg)
            self.waiting = True
            # Print cleanly
            sys.stdout.write(f'\r  [{self.selected_bot}] {full_cmd}                    \n')
            sys.stdout.write(f'  > ')
            sys.stdout.flush()

    def move_forward(self):
        self.send_cmd(f'MOVE:{float(self.grid_size):.1f}')

    def turn_left(self):
        self.heading = (self.heading - 90) % 360
        self.send_cmd(f'ROTATE:{self.heading:.1f}')

    def turn_right(self):
        self.heading = (self.heading + 90) % 360
        self.send_cmd(f'ROTATE:{self.heading:.1f}')

    def turn_around(self):
        self.heading = (self.heading + 180) % 360
        self.send_cmd(f'ROTATE:{self.heading:.1f}')

    def select_bot(self, num):
        bid = f'bot_{num:02d}'
        if bid in self.bot_ids:
            self.selected_bot = bid
            self.heading = 0.0
            sys.stdout.write(f'\r  Selected: {bid}                    \n  > ')
            sys.stdout.flush()


def print_banner():
    print()
    print('╔══════════════════════════════════════╗')
    print('║      SWARM BOT TELEOP CONTROL        ║')
    print('╠══════════════════════════════════════╣')
    print('║  ↑ / W  = Move forward (1 grid cell)  ║')
    print('║  ← / A  = Turn left 90°               ║')
    print('║  → / D  = Turn right 90°              ║')
    print('║  ↓ / S  = Turn around 180°            ║')
    print('║  1-9    = Select bot                   ║')
    print('║  Q      = Quit                         ║')
    print('╚══════════════════════════════════════╝')
    print()


def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    print_banner()
    print(f'  Active: {node.selected_bot}  |  Grid: {node.grid_size}mm')
    print(f'  > ', end='', flush=True)

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    try:
        # Set terminal to raw mode ONCE (not per-keypress)
        tty.setcbreak(fd)

        while rclpy.ok():
            # Check for keyboard input (non-blocking)
            rlist, _, _ = select.select([sys.stdin], [], [], 0.05)

            # Spin ROS2
            rclpy.spin_once(node, timeout_sec=0.01)

            if not rlist:
                continue

            ch = os.read(fd, 1).decode('utf-8', errors='ignore')

            # Arrow keys: ESC [ A/B/C/D
            if ch == '\x1b':
                # Read the next 2 bytes of the escape sequence
                rlist2, _, _ = select.select([sys.stdin], [], [], 0.05)
                if rlist2:
                    ch2 = os.read(fd, 1).decode('utf-8', errors='ignore')
                    if ch2 == '[':
                        rlist3, _, _ = select.select([sys.stdin], [], [], 0.05)
                        if rlist3:
                            ch3 = os.read(fd, 1).decode('utf-8', errors='ignore')
                            if ch3 == 'A':    node.move_forward()
                            elif ch3 == 'B':  node.turn_around()
                            elif ch3 == 'C':  node.turn_right()
                            elif ch3 == 'D':  node.turn_left()
                continue

            # WASD keys (case insensitive)
            ch_lower = ch.lower()
            if ch_lower == 'w':
                node.move_forward()
            elif ch_lower == 'a':
                node.turn_left()
            elif ch_lower == 'd':
                node.turn_right()
            elif ch_lower == 's':
                node.turn_around()
            elif ch_lower == 'q':
                sys.stdout.write('\r  Quitting...                         \n')
                break
            elif ch in '123456789':
                node.select_bot(int(ch))

    except KeyboardInterrupt:
        pass
    finally:
        # Restore terminal
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        print()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
