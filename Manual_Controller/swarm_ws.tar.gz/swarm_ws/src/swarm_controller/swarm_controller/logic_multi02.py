"""
logic_multi02.py — Multi-bot swarm orchestrator using logic02 pathfinding.

Architecture:
  - Uses Hungarian algorithm for block→goal and bot→task assignment
  - For each bot-task pair, builds a single-bot "virtual state" and calls
    logic02.compute_swarm_moves to get the move
  - Resolves collisions between bots afterwards
  - Tracks per-bot state in MULTI_STATE (separate from logic02.BOT_STATES)
"""

from scipy.optimize import linear_sum_assignment
import numpy as np
import logic02
from logic02 import (
    _snap, _pos_eq, _close, SNAP, TURN_WEIGHT,
    classify_obstacles, find_optimal_block_path, BOT_STATES,
    _estimate_ticks,
)

# ── Global multi-bot state ────────────────────────────────────────────────────

MULTI_STATE = {
    'assignments':   {},    # bot_id -> task dict or None
    'task_pool':     [],    # unassigned tasks
    'placed_blocks': set(), # block_ids that reached their goal
    'initialised':   False,
}

STUCK_LIMIT    = 5
REASSIGN_LIMIT = 20


def reset_logic():
    """Reset all multi-bot and single-bot state."""
    MULTI_STATE['assignments'].clear()
    MULTI_STATE['task_pool'].clear()
    MULTI_STATE['placed_blocks'].clear()
    MULTI_STATE['initialised'] = False
    logic02.reset_logic()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _manhattan(p1, p2):
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


def _is_real_task(assignment):
    return (assignment is not None
            and isinstance(assignment, dict)
            and 'block_id' in assignment)


# ── Block → Goal pairing (Hungarian) ─────────────────────────────────────────

def _pair_blocks_to_goals(blocks, goals, grid):
    """Pair blocks to goals using Hungarian algorithm."""
    if not blocks or not goals:
        return []
    n, m = len(blocks), len(goals)
    cost = [[_manhattan(blocks[i]['pos'], goals[j]['pos'])
             for j in range(m)] for i in range(n)]
    row_ind, col_ind = linear_sum_assignment(np.array(cost))
    return [{
        'block_id':  blocks[r]['id'],
        'block_pos': blocks[r]['pos'],
        'goal_pos':  goals[c]['pos'],
    } for r, c in zip(row_ind, col_ind)]


# ── Bot → Task assignment (Hungarian) ────────────────────────────────────────

def _task_cost(bot_pos, block_pos, goal_pos, grid):
    """Estimate cost for a bot to complete a task."""
    # Nav to block + push block to goal
    nav_dist = _manhattan(bot_pos, block_pos)
    push_dist = _manhattan(block_pos, goal_pos)
    return nav_dist + push_dist


def _assign_bots_to_tasks(free_bots, tasks, grid):
    """Assign bots to tasks using Hungarian algorithm."""
    if not free_bots or not tasks:
        return {}
    n, m = len(free_bots), len(tasks)
    cost = [[_task_cost(free_bots[i]['pos'], tasks[j]['block_pos'],
                        tasks[j]['goal_pos'], grid)
             for j in range(m)] for i in range(n)]
    row_ind, col_ind = linear_sum_assignment(np.array(cost))
    return {free_bots[r]['id']: tasks[c] for r, c in zip(row_ind, col_ind)}


# ── Collision resolution ─────────────────────────────────────────────────────

def _resolve_collisions(proposals, all_bot_positions, all_block_positions, grid):
    """
    Given proposed moves for all bots, resolve conflicts.
    proposals: {bot_id: (cur_x, cur_y, dx, dy, pushing, block_next_pos)}
    Returns: {bot_id: (final_dx, final_dy, was_allowed)}
    """
    # Build occupancy maps
    bot_cells = {pos: bid for bid, pos in all_bot_positions.items()}
    block_cells = {pos: blk_id for blk_id, pos in all_block_positions.items()}
    
    # Track which bot is pushing which block
    pushing_bots = {}
    for bid, (cx, cy, dx, dy, pushing, blk_next) in proposals.items():
        if pushing:
            blk_pos = (cx + dx, cy + dy)
            blk_id = block_cells.get(blk_pos)
            if blk_id:
                pushing_bots[bid] = blk_id
    
    # Priority: pushing bots go first
    priority_order = sorted(proposals.keys(),
                           key=lambda b: (0 if proposals[b][4] else 1, b))
    
    claimed_cells = {}
    allowed = {}
    
    for bid in priority_order:
        cx, cy, dx, dy, pushing, blk_next = proposals[bid]
        
        if dx == 0 and dy == 0:
            allowed[bid] = True
            continue
        
        nx, ny = cx + dx, cy + dy
        
        # Check: is destination occupied by another bot that isn't moving?
        occupant = bot_cells.get((nx, ny))
        if occupant and occupant != bid:
            occ_prop = proposals.get(occupant, (0, 0, 0, 0, False, None))
            if occ_prop[2] == 0 and occ_prop[3] == 0:
                # Occupant is stationary — can't move there
                allowed[bid] = False
                continue
        
        # Check: is destination claimed by a higher-priority bot?
        if (nx, ny) in claimed_cells:
            allowed[bid] = False
            continue
        
        # If pushing, check the block's destination too
        if pushing and blk_next:
            bx2, by2 = blk_next
            if (bx2, by2) in claimed_cells:
                allowed[bid] = False
                continue
            # Block dest occupied by another bot or block?
            if bot_cells.get((bx2, by2)) and bot_cells[(bx2, by2)] != bid:
                allowed[bid] = False
                continue
            other_blk = block_cells.get((bx2, by2))
            if other_blk and other_blk != pushing_bots.get(bid):
                allowed[bid] = False
                continue
        
        # Allow this move
        allowed[bid] = True
        claimed_cells[(nx, ny)] = bid
        if pushing and blk_next:
            claimed_cells[blk_next] = f"{bid}:block"
    
    result = {}
    for bid in proposals:
        if allowed.get(bid, False):
            result[bid] = (proposals[bid][2], proposals[bid][3], True)
        else:
            result[bid] = (0, 0, False)
    return result


# ── Per-bot move computation using logic02 ────────────────────────────────────

def _compute_single_bot_move(bot_id, bot_pos, bot_facing, block_pos, goal_pos,
                              all_bots, all_blocks, grid_size):
    """
    Build a virtual single-bot state and call logic02.compute_swarm_moves.
    
    ALL other bots are added as potential helpers (logic02 will evaluate
    whether any of them can help via _plan_helper_push). This includes
    both idle bots and active bots — the orchestrator decides later whether
    to accept the helper assignment based on cost-benefit.
    
    Returns: (dx, dy, push_id, helper_moves)
      helper_moves: dict of {helper_bot_id: (hdx, hdy, hpush_id)} or empty
    """
    # Build virtual state for logic02
    virtual_state = {
        'bots': [
            {'id': bot_id, 'pos': list(bot_pos), 'facing': bot_facing},
        ],
        'blocks': [
            {'id': 'active_block', 'pos': list(block_pos)},
        ],
        'goals': [
            {'id': 'goal', 'pos': list(goal_pos)},
        ],
    }
    
    # Add ALL other bots as potential helpers
    for other_bot in all_bots:
        if other_bot['id'] != bot_id:
            virtual_state['bots'].append({
                'id': other_bot['id'],
                'pos': list(other_bot['pos']),
                'facing': other_bot.get('facing', (1, 0)),
            })
    
    # Add other blocks as obstacle blocks
    for other_block in all_blocks:
        if not _pos_eq(other_block['pos'], block_pos):
            virtual_state['blocks'].append({
                'id': f'obs_{other_block["id"]}',
                'pos': list(other_block['pos']),
            })
    
    # Call logic02's compute_swarm_moves
    result = logic02.compute_swarm_moves(virtual_state, grid_size)
    
    if result is None:
        return (0, 0, None, {})
    
    # Extract moves for all bots
    move = result.get(bot_id, (0, 0, None))
    dx, dy, push_id = move
    
    # Map back: if pushing 'active_block', return the real block_id
    real_push_id = None
    if push_id == 'active_block':
        for blk in all_blocks:
            if _pos_eq(blk['pos'], block_pos):
                real_push_id = blk['id']
                break
    elif push_id is not None:
        real_push_id = push_id
    
    # Collect helper moves (other bots that logic02 decided to move)
    helper_moves = {}
    for other_bot in all_bots:
        if other_bot['id'] == bot_id:
            continue
        h_move = result.get(other_bot['id'], (0, 0, None))
        if h_move[0] != 0 or h_move[1] != 0:
            hdx, hdy, hpush = h_move
            # Map push_id back
            h_real_push = None
            if hpush == 'active_block':
                for blk in all_blocks:
                    if _pos_eq(blk['pos'], block_pos):
                        h_real_push = blk['id']
                        break
            elif hpush is not None:
                h_real_push = hpush
            helper_moves[other_bot['id']] = (hdx, hdy, h_real_push)
    
    return (dx, dy, real_push_id, helper_moves)


# ── Main entry point ─────────────────────────────────────────────────────────

def compute_swarm_moves(state, grid_size):
    """
    Multi-bot orchestrator. Called by the UI each tick.
    
    Returns: {'moves': {bot_id: (dx, dy, block_id)}, 'assignments': {...}}
    """
    G = grid_size
    ms = MULTI_STATE
    
    bots = [{'id': b['id'],
             'pos': (_snap(b['pos'][0], G), _snap(b['pos'][1], G)),
             'facing': b.get('facing', (1, 0))}
            for b in state['bots']]
    blocks = [{'id': b['id'],
               'pos': (_snap(b['pos'][0], G), _snap(b['pos'][1], G))}
              for b in state['blocks']]
    goals = [{'id': g['id'],
              'pos': (_snap(g['pos'][0], G), _snap(g['pos'][1], G))}
             for g in state['goals']]
    
    if not bots:
        return {'moves': {}, 'assignments': {}}
    
    bot_pos_map = {b['id']: b['pos'] for b in bots}
    block_by_id = {b['id']: b for b in blocks}
    
    # ── Initialization: pair blocks→goals, assign bots→tasks ──────────────
    if not ms['initialised']:
        ms['initialised'] = True
        logic02.reset_logic()
        
        tasks = _pair_blocks_to_goals(blocks, goals, G)
        ms['task_pool'] = tasks[:]
        
        free_bots = [{'id': b['id'], 'pos': b['pos'], 'facing': b.get('facing', (1, 0))}
                     for b in bots]
        new_assigned = _assign_bots_to_tasks(free_bots, ms['task_pool'], G)
        
        for bot_id, task in new_assigned.items():
            ms['assignments'][bot_id] = task
        
        used_ids = {t['block_id'] for t in new_assigned.values()}
        ms['task_pool'] = [t for t in ms['task_pool'] if t['block_id'] not in used_ids]
        
        # Mark unassigned bots as idle
        for b in bots:
            if b['id'] not in ms['assignments']:
                ms['assignments'][b['id']] = None
    
    # ── Update block positions in assignments ─────────────────────────────
    for bot_id, task in ms['assignments'].items():
        if not _is_real_task(task):
            continue
        block = block_by_id.get(task['block_id'])
        if block:
            task['block_pos'] = block['pos']
    
    # ── Check for completed tasks ─────────────────────────────────────────
    freed_bots = []
    for bot_id, task in list(ms['assignments'].items()):
        if not _is_real_task(task):
            continue
        block = block_by_id.get(task['block_id'])
        if block is None:
            continue
        if _pos_eq(block['pos'], task['goal_pos']):
            ms['placed_blocks'].add(task['block_id'])
            ms['assignments'][bot_id] = {'done': True}
            # Clear this bot's logic02 state
            if bot_id in BOT_STATES:
                del BOT_STATES[bot_id]
            freed_bots.append(bot_id)
    
    # ── Reassign freed bots to remaining tasks ────────────────────────────
    if freed_bots and ms['task_pool']:
        free_bot_list = [{'id': bid, 'pos': bot_pos_map.get(bid, (0, 0)),
                          'facing': (1, 0)} for bid in freed_bots]
        new_assigned = _assign_bots_to_tasks(free_bot_list, ms['task_pool'], G)
        for bot_id, task in new_assigned.items():
            ms['assignments'][bot_id] = task
            # Clear old logic02 state so it re-initializes
            if bot_id in BOT_STATES:
                del BOT_STATES[bot_id]
        used_ids = {t['block_id'] for t in new_assigned.values()}
        ms['task_pool'] = [t for t in ms['task_pool'] if t['block_id'] not in used_ids]
    
    # ── Compute moves for each bot ────────────────────────────────────────
    all_bot_positions = {b['id']: b['pos'] for b in bots}
    all_block_positions = {b['id']: b['pos'] for b in blocks}
    proposals = {}
    
    # Track helper assignments: helper_id -> (requester_id, hdx, hdy, hpush_id)
    helper_assignments = {}
    
    for bot in bots:
        bot_id = bot['id']
        bot_x, bot_y = bot['pos']
        task = ms['assignments'].get(bot_id)
        
        if not _is_real_task(task):
            proposals[bot_id] = (bot_x, bot_y, 0, 0, False, None)
            continue
        
        block = block_by_id.get(task['block_id'])
        if block is None:
            proposals[bot_id] = (bot_x, bot_y, 0, 0, False, None)
            continue
        
        b_x, b_y = block['pos']
        g_x, g_y = task['goal_pos']
        
        # Get move from logic02 (returns helper_moves too)
        dx, dy, push_id, helper_moves = _compute_single_bot_move(
            bot_id, (bot_x, bot_y), bot.get('facing', (1, 0)),
            (b_x, b_y), (g_x, g_y),
            bots, blocks, G
        )
        
        pushing = push_id is not None
        blk_next = (b_x + dx, b_y + dy) if pushing else None
        proposals[bot_id] = (bot_x, bot_y, dx, dy, pushing, blk_next)
        
        # Record helper moves — each helper can only help one requester
        for h_id, (hdx, hdy, hpush) in helper_moves.items():
            if h_id not in helper_assignments:
                helper_assignments[h_id] = (bot_id, hdx, hdy, hpush)
    
    # ── Apply helper overrides ────────────────────────────────────────────
    # If a bot is assigned as helper, override its own proposal with the helper move
    for helper_id, (requester_id, hdx, hdy, hpush) in helper_assignments.items():
        h_pos = all_bot_positions.get(helper_id, (0, 0))
        h_pushing = hpush is not None
        h_blk_next = None
        if h_pushing:
            req_task = ms['assignments'].get(requester_id)
            if _is_real_task(req_task):
                req_blk = block_by_id.get(req_task['block_id'])
                if req_blk:
                    h_blk_next = (req_blk['pos'][0] + hdx, req_blk['pos'][1] + hdy)
        proposals[helper_id] = (h_pos[0], h_pos[1], hdx, hdy, h_pushing, h_blk_next)
    
    # ── Resolve collisions ────────────────────────────────────────────────
    resolution = _resolve_collisions(
        proposals, all_bot_positions, all_block_positions, G)
    
    # ── Build final moves ─────────────────────────────────────────────────
    moves = {}
    assignments_out = {}
    
    for bot in bots:
        bot_id = bot['id']
        fin_dx, fin_dy, was_allowed = resolution.get(bot_id, (0, 0, True))
        
        # If move was blocked, we need to reset logic02 state for this bot
        # so it replans next tick
        if not was_allowed and bot_id in BOT_STATES:
            # Don't delete — let logic02's stuck detection handle it
            pass
        
        # Determine block_id for push
        block_id_out = None
        if was_allowed:
            orig = proposals.get(bot_id, (0, 0, 0, 0, False, None))
            if orig[4]:  # was pushing
                # Check if this bot is a helper pushing someone else's block
                if bot_id in helper_assignments:
                    req_id = helper_assignments[bot_id][0]
                    req_task = ms['assignments'].get(req_id)
                    if _is_real_task(req_task):
                        block_id_out = req_task['block_id']
                else:
                    task = ms['assignments'].get(bot_id)
                    if _is_real_task(task):
                        block_id_out = task['block_id']
        
        moves[bot_id] = (fin_dx, fin_dy, block_id_out)
        
        # Build assignment output for UI
        task = ms['assignments'].get(bot_id)
        if task is None:
            assignments_out[bot_id] = None
        elif task.get('done'):
            assignments_out[bot_id] = {'done': True}
        elif _is_real_task(task):
            assignments_out[bot_id] = {
                'block_pos': task.get('block_pos', (0, 0)),
                'goal_pos': task['goal_pos'],
            }
        else:
            assignments_out[bot_id] = None
    
    return {'moves': moves, 'assignments': assignments_out}
