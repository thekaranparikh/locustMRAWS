"""
orchestrator_node.py — Central brain. Reads camera, calls logic, sends commands.
Uses std_msgs/String for ESP communication.
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from swarm_interfaces.msg import ArenaState
from swarm_controller import logic_multi02 as logic
from swarm_controller.logic02 import _snap


class OrchestratorNode(Node):
    def __init__(self):
        super().__init__('swarm_orchestrator')
        self.declare_parameter('grid_size_mm', 150)
        self.declare_parameter('bot_ids', ['bot_01', 'bot_02'])
        self.grid_size = self.get_parameter('grid_size_mm').value
        self.bot_ids = self.get_parameter('bot_ids').value
        self.seq = 0
        self.latest_arena_state = None
        self.waiting_for_bots = set()

        self.arena_sub = self.create_subscription(
            ArenaState, '/arena_state', self.on_arena_state, 10)
        self.cmd_pubs = {}
        for bid in self.bot_ids:
            self.cmd_pubs[bid] = self.create_publisher(String, f'/{bid}/cmd', 10)
            self.create_subscription(
                String, f'/{bid}/status',
                lambda msg, b=bid: self.on_bot_status(b, msg), 10)

        self.tick_timer = self.create_timer(0.5, self.tick_loop)
        logic.reset_logic()
        self.get_logger().info(f'Orchestrator ready: grid={self.grid_size}mm, bots={self.bot_ids}')

    def on_arena_state(self, msg): self.latest_arena_state = msg

    def on_bot_status(self, bot_id, msg):
        parts = msg.data.split(':')
        if len(parts) >= 3 and parts[1] == 'DONE' and bot_id in self.waiting_for_bots:
            self.waiting_for_bots.discard(bot_id)
            self.get_logger().info(f'{bot_id} DONE')

    def tick_loop(self):
        if self.waiting_for_bots or self.latest_arena_state is None:
            return
        G = self.grid_size
        state = {'bots': [], 'blocks': [], 'goals': []}
        for bp in self.latest_arena_state.bots:
            h = bp.heading_deg % 360
            if h < 45 or h >= 315:    f = (1,0)
            elif h < 135:             f = (0,1)
            elif h < 225:             f = (-1,0)
            else:                     f = (0,-1)
            state['bots'].append({'id': bp.bot_id, 'pos': (_snap(bp.x_mm,G), _snap(bp.y_mm,G)), 'facing': f})
        for op in self.latest_arena_state.blocks:
            state['blocks'].append({'id': op.object_id, 'pos': (_snap(op.x_mm,G), _snap(op.y_mm,G))})
        for op in self.latest_arena_state.goals:
            state['goals'].append({'id': op.object_id, 'pos': (_snap(op.x_mm,G), _snap(op.y_mm,G))})
        if not state['bots']: return

        result = logic.compute_swarm_moves(state, G)
        moves, assignments = result['moves'], result['assignments']
        if all(a is None or a.get('done') for a in assignments.values()) and self.seq > 0:
            self.get_logger().info('ALL TASKS COMPLETE!')
            self.tick_timer.cancel()
            return

        self.seq += 1
        active = set()
        for bot_id, (dx, dy, block_id) in moves.items():
            if dx == 0 and dy == 0: continue
            if dx > 0: th = 0.0
            elif dx < 0: th = 180.0
            elif dy > 0: th = 90.0
            else: th = 270.0
            cur = self._get_heading(bot_id)
            diff = (th - cur) % 360 if cur is not None else 0
            if diff > 180: diff -= 360
            if cur is not None and abs(diff) > 15:
                cmd = f'ROTATE:{th:.1f}:{self.seq}'
            else:
                cmd = f'MOVE:{float(G):.1f}:{self.seq}'
            msg = String(); msg.data = cmd
            self.cmd_pubs[bot_id].publish(msg)
            active.add(bot_id)
            self.get_logger().info(f'  {bot_id}: {cmd}{" [PUSH]" if block_id else ""}')
        if active: self.waiting_for_bots = active

    def _get_heading(self, bot_id):
        if self.latest_arena_state:
            for bp in self.latest_arena_state.bots:
                if bp.bot_id == bot_id: return bp.heading_deg
        return None

def main(args=None):
    rclpy.init(args=args)
    node = OrchestratorNode()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()

if __name__ == '__main__':
    main()
