"""
test_sim_node.py — Fake camera + bots for testing without hardware.
"""
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from swarm_interfaces.msg import ArenaState, BotPose, ObjectPose
import math

class TestSimNode(Node):
    def __init__(self):
        super().__init__('test_sim')
        self.declare_parameter('grid_size_mm', 150)
        self.declare_parameter('bot_ids', ['bot_01', 'bot_02'])
        G = self.get_parameter('grid_size_mm').value
        self.bot_ids = self.get_parameter('bot_ids').value
        self.grid = G
        self.bots = {
            'bot_01': {'x': 1.5*G, 'y': 1.0*G, 'heading': 0.0},
            'bot_02': {'x': 5.0*G, 'y': 2.0*G, 'heading': 0.0},
        }
        self.blocks = {'block_01': {'x': 3.0*G, 'y': 3.0*G}, 'block_02': {'x': 6.0*G, 'y': 4.0*G}}
        self.goals = {'goal_01': {'x': 5.0*G, 'y': 6.0*G}, 'goal_02': {'x': 8.0*G, 'y': 7.0*G}}
        self.pending = {}
        self.state_pub = self.create_publisher(ArenaState, '/arena_state', 10)
        self.status_pubs = {}
        for bid in self.bot_ids:
            self.create_subscription(String, f'/{bid}/cmd', lambda msg, b=bid: self.on_cmd(b, msg), 10)
            self.status_pubs[bid] = self.create_publisher(String, f'/{bid}/status', 10)
        self.create_timer(0.1, self.publish_state)
        self.create_timer(0.2, self.process_commands)
        self.get_logger().info(f'Test sim ready: {list(self.bots.keys())}')

    def on_cmd(self, bot_id, msg):
        self.get_logger().info(f'CMD {bot_id}: {msg.data}')
        self.pending[bot_id] = msg.data

    def process_commands(self):
        G = self.grid
        for bid, cmd_str in list(self.pending.items()):
            bot = self.bots.get(bid)
            if not bot: continue
            parts = cmd_str.split(':')
            if len(parts) < 3: continue
            t, v, s = parts[0], float(parts[1]), int(parts[2])
            if t == 'ROTATE':
                bot['heading'] = v
            elif t == 'MOVE':
                rad = math.radians(bot['heading'])
                bot['x'] += math.cos(rad)*G; bot['y'] += math.sin(rad)*G
                for blk in self.blocks.values():
                    if abs(bot['x']-blk['x'])<5 and abs(bot['y']-blk['y'])<5:
                        blk['x'] += math.cos(rad)*G; blk['y'] += math.sin(rad)*G; break
            m = String(); m.data = f'{bid}:DONE:{s}:0.0:0.0:{bot["heading"]:.1f}'
            self.status_pubs[bid].publish(m)
            del self.pending[bid]

    def publish_state(self):
        msg = ArenaState()
        for bid, b in self.bots.items():
            bp = BotPose(); bp.bot_id = bid; bp.x_mm = b['x']; bp.y_mm = b['y']; bp.heading_deg = b['heading']
            msg.bots.append(bp)
        for bid, b in self.blocks.items():
            op = ObjectPose(); op.object_id = bid; op.x_mm = b['x']; op.y_mm = b['y']
            msg.blocks.append(op)
        for gid, g in self.goals.items():
            op = ObjectPose(); op.object_id = gid; op.x_mm = g['x']; op.y_mm = g['y']
            msg.goals.append(op)
        self.state_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    n = TestSimNode()
    try: rclpy.spin(n)
    except KeyboardInterrupt: pass
    finally: n.destroy_node(); rclpy.shutdown()

if __name__ == '__main__': main()
