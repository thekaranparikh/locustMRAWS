"""
camera_node.py — Overhead camera ArUco detection → ArenaState publisher.
"""
import rclpy
from rclpy.node import Node
from swarm_interfaces.msg import ArenaState, BotPose, ObjectPose
import cv2
import cv2.aruco as aruco
import numpy as np
import yaml, os

class CameraNode(Node):
    def __init__(self):
        super().__init__('camera_node')
        self.declare_parameter('camera_index', 0)
        self.declare_parameter('grid_size_mm', 150)
        self.declare_parameter('config_file', '')
        self.declare_parameter('bot_aruco_ids', [1, 2, 3, 4, 5, 6, 7, 8])
        self.declare_parameter('block_aruco_ids', [10, 11, 12, 13, 14, 15])
        self.grid_size = self.get_parameter('grid_size_mm').value
        self.bot_aruco_ids = self.get_parameter('bot_aruco_ids').value
        self.block_aruco_ids = self.get_parameter('block_aruco_ids').value
        self.camera_matrix = self.dist_coeffs = self.homography = None
        self.goal_positions = []
        cf = self.get_parameter('config_file').value
        if cf and os.path.exists(cf):
            cal = yaml.safe_load(open(cf))
            self.camera_matrix = np.array(cal.get('camera_matrix',[]))
            self.dist_coeffs = np.array(cal.get('dist_coeffs',[]))
            if 'homography' in cal: self.homography = np.array(cal['homography'])
            self.goal_positions = cal.get('goals',[])
        self.aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
        self.aruco_params = aruco.DetectorParameters()
        self.cap = cv2.VideoCapture(self.get_parameter('camera_index').value)
        self.state_pub = self.create_publisher(ArenaState, '/arena_state', 10)
        self.create_timer(1.0/15.0, self.capture_and_publish)
        self.get_logger().info('Camera node started')

    def pixel_to_arena(self, px, py):
        if self.homography is not None:
            pt = np.array([px, py, 1.0])
            r = self.homography @ pt
            return float(r[0]/r[2]), float(r[1]/r[2])
        return float(px), float(py)

    def capture_and_publish(self):
        ret, frame = self.cap.read()
        if not ret: return
        if self.camera_matrix is not None:
            frame = cv2.undistort(frame, self.camera_matrix, self.dist_coeffs)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = aruco.detectMarkers(gray, self.aruco_dict, parameters=self.aruco_params)
        msg = ArenaState()
        if ids is not None:
            for i, mid in enumerate(ids.flatten()):
                c = corners[i][0]
                cx, cy = float(np.mean(c[:,0])), float(np.mean(c[:,1]))
                ax, ay = self.pixel_to_arena(cx, cy)
                if mid in self.bot_aruco_ids:
                    bp = BotPose()
                    bp.bot_id = f'bot_{mid:02d}'
                    bp.x_mm = ax; bp.y_mm = ay
                    dx = c[1][0]-c[0][0]; dy = c[1][1]-c[0][1]
                    bp.heading_deg = float(np.degrees(np.arctan2(dy, dx)) % 360)
                    msg.bots.append(bp)
                elif mid in self.block_aruco_ids:
                    op = ObjectPose()
                    op.object_id = f'block_{mid:02d}'
                    op.x_mm = ax; op.y_mm = ay
                    msg.blocks.append(op)
        for g in self.goal_positions:
            op = ObjectPose(); op.object_id = g['id']
            op.x_mm = float(g['x_mm']); op.y_mm = float(g['y_mm'])
            msg.goals.append(op)
        self.state_pub.publish(msg)

    def destroy_node(self):
        if self.cap.isOpened(): self.cap.release()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    n = CameraNode()
    try: rclpy.spin(n)
    except KeyboardInterrupt: pass
    finally: n.destroy_node(); rclpy.shutdown()

if __name__ == '__main__': main()
