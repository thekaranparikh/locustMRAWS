from launch import LaunchDescription
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_dir = get_package_share_directory('swarm_controller')
    config = os.path.join(pkg_dir, 'config', 'swarm_config.yaml')
    return LaunchDescription([
        Node(package='swarm_controller', executable='camera',
             name='camera_node', parameters=[config], output='screen'),
        Node(package='swarm_controller', executable='orchestrator',
             name='orchestrator_node', parameters=[config], output='screen'),
    ])
