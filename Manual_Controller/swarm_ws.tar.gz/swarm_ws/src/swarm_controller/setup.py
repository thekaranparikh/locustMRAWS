from setuptools import setup, find_packages
from glob import glob

package_name = 'swarm_controller'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.py')),
        ('share/' + package_name + '/config', glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='swarm_team',
    maintainer_email='you@example.com',
    description='Swarm bot orchestrator',
    license='MIT',
    entry_points={
        'console_scripts': [
            'orchestrator = swarm_controller.orchestrator_node:main',
            'camera = swarm_controller.camera_node:main',
            'test_sim = swarm_controller.test_sim_node:main',
            'teleop = swarm_controller.teleop_node:main',
        ],
    },
)
